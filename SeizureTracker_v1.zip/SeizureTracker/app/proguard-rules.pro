# Add project specific ProGuard rules here.
-keepattributes *Annotation*
-keepclassmembers class com.atnip.seizuretracker.data.model.** {
  *;
}
